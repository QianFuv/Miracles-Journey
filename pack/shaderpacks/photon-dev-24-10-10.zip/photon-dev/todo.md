## fixes
- cloud shadows broken on OptiFine

## features
- rework rainy weather

### sky
- noctilucent clouds
- improve aurora
- crepuscular rays
